package com.example.project5;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {
    private Button orderPizza;
    private Button currentOrderCart;
    private Button storeOrders;
    public static StoreOrder allOrdersFromStore = new StoreOrder();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        Order currentOrder = new Order();
        allOrdersFromStore.add(currentOrder);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main_layout);
        orderPizza = findViewById(R.id.orderPizzaButton);
        currentOrderCart = findViewById(R.id.currentOrderCartButton);
        storeOrders = findViewById(R.id.storeOrdersButton);
        orderPizza.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openPizzaView();
            }
        });
        currentOrderCart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openCartView();
            }
        });
        storeOrders.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openStoreOrdersView();
            }
        });
    }

    public void openPizzaView() {
        Intent intent = new Intent(this, OrderPizzaActivity.class);
        startActivity(intent);
    }

    public void openCartView() {
        Intent intent = new Intent(this, ShoppingCartActivity.class);
        startActivity(intent);
    }

    public void openStoreOrdersView() {
//        Intent intent = new Intent(this, StoreOrdersActivity.class);
//        startActivity(intent);
    }

    public StoreOrder getAllOrdersFromStore() {
        return allOrdersFromStore;
    }
}

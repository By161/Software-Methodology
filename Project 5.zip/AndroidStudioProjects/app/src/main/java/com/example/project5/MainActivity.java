package com.example.project5;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.Spinner;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

/**
 * The MainActivity class manages the main menu view for the application and manages the data
 * for the whole program
 * @author Brandon Yuen, Anna Kryzanekas
 */
public class MainActivity extends AppCompatActivity {

    /**
     * A Spinner to select the Pizza size
     */
    public static Spinner sizes;
    /**
     * A CheckBox to select toppings
     */
    private CheckBox toppings;
    /**
     * The Pizza object to be added to the order
     */
    private Pizza pizza;
    /**
     * A Button to submit the Pizza to the order
     */
    private Button submit;
    /**
     * The TextView that displays the cost of the Pizza
     */
    private TextView label;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        RecyclerView recyclerView = findViewById(R.id.recyclerview);

        List<Item> pizzas = new ArrayList<Item>();
        pizzas.add (new Item("Chicago Deluxe", R.drawable.deluxechicagopizza));
        pizzas.add (new Item("Chicago BBQ Chicken", R.drawable.chicagobbqchickenpizza));
        pizzas.add (new Item("Chicago Meatzza", R.drawable.chicagomeatzza));
        pizzas.add (new Item("Chicago Build Your Own", R.drawable.chicagomakeyourown));
        pizzas.add (new Item("NY Deluxe", R.drawable.nydeluxepizza));
        pizzas.add (new Item("NY BBQ Chicken", R.drawable.nybbqchicken));
        pizzas.add (new Item("NY Meatzza", R.drawable.meatzza));
        pizzas.add (new Item("NY Build Your Own", R.drawable.buildyourown));
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(new MyAdapter(getApplicationContext(), pizzas));
    }

}
package com.example.project5;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * The MainActivity class manages the main menu view for the application and manages the data
 * for the whole program
 * @author Brandon Yuen, Anna Kryzanekas
 */
public class RecyclerViewActivity extends AppCompatActivity implements RecyclerViewInterface {

    List<Item> pizzas = new ArrayList<Item>();

    public static ArrayList<String> listToppingsBuildYourOwn = new ArrayList<>();

    public static ArrayList<String> listToppingsDeluxe = new ArrayList<String>(Arrays.asList("Sausage",
            "pepperoni", "green pepper", "onion", "mushroom"));

    public static ArrayList<String> listToppingsBBQChicken = new ArrayList<String>(Arrays.asList("BBQ Chicken",
            "green pepper", "provolone", "cheddar"));

    public static ArrayList<String> listToppingsMeatzza = new ArrayList<String>(Arrays.asList("Sausage",
            "pepperoni", "beef", "ham"));
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.choose_flavor_main);

        RecyclerView recyclerView = findViewById(R.id.recyclerview);

        pizzas.add (new Item("Chicago Deluxe", R.drawable.deluxechicagopizza));
        pizzas.add (new Item("Chicago BBQ Chicken", R.drawable.chicagobbqchickenpizza));
        pizzas.add (new Item("Chicago Meatzza", R.drawable.chicagomeatzza));
        pizzas.add (new Item("Chicago Build Your Own", R.drawable.chicagomakeyourown));
        pizzas.add (new Item("NY Deluxe", R.drawable.nydeluxepizza));
        pizzas.add (new Item("NY BBQ Chicken", R.drawable.nybbqchicken));
        pizzas.add (new Item("NY Meatzza", R.drawable.meatzza));
        pizzas.add (new Item("NY Build Your Own", R.drawable.buildyourown));
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(new recyclerViewAdapter(getApplicationContext(), pizzas, this));
    }

    @Override
    public void onItemClick(int position) {
        Intent intent = new Intent(RecyclerViewActivity.this, editPizzaActivity.class);
        String flavor = String.valueOf(R.id.name);
        switch (flavor){
            case "Chicago Deluxe" : intent.putExtra("Flavor", "Chicago Deluxe");
                startActivity(intent);
                break;
            case "Chicago BBQ Chicken" : intent.putExtra("Flavor", "Chicago BBQ Chicken");
                startActivity(intent);
                break;
            case "Chicago Meatzza" : intent.putExtra("Flavor", "Chicago Meatzza");
                startActivity(intent);
                break;
            case "Chicago Build Your Own" : intent.putExtra("Flavor", "Chicago Build Your Own");
                startActivity(intent);
                break;
            case "NY Deluxe" : intent.putExtra("Flavor", "NY Deluxe");
                startActivity(intent);
                break;
            case "NY BBQ Chicken" : intent.putExtra("Flavor", "NY BBQ Chicken");
                startActivity(intent);
                break;
            case "NY Meatzza" : intent.putExtra("Flavor", "NY Meatzza");
                startActivity(intent);
                break;
            default:
                intent.putExtra("Flavor", "NY Build Your Own");
                startActivity(intent);
        }
    }
}
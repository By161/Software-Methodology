package com.example.project5;

/**
 * Required class for to make the crust object
 * @author Brandon Yuen, Anna Kryzanekas
 */
public class Crust {
    String crust;

    public Crust (String crust){
        this.crust = crust;
    }

    public String getCrust(){
        return this.crust;
    }
    public String toString(){
        return this.crust;
    }
}

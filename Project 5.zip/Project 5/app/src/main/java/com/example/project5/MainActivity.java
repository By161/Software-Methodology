package com.example.project5;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

/**
 * Main Activity controller
 * @author Brandon Yuen, Anna Kryzanekas
 */
public class MainActivity extends AppCompatActivity {
    private Button orderPizza;
    private Button currentOrderCart;
    private Button storeOrders;
    public static StoreOrder allOrdersFromStore = new StoreOrder();

    /**
     * onCreate method to make the activity
     * @param savedInstanceState the saved instance state
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        Order currentOrder = new Order();
        allOrdersFromStore.add(currentOrder);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main_layout);
        orderPizza = findViewById(R.id.orderPizzaButton);
        currentOrderCart = findViewById(R.id.currentOrderCartButton);
        storeOrders = findViewById(R.id.storeOrdersButton);
        orderPizza.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openPizzaView();
            }
        });
        currentOrderCart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openCartView();
            }
        });
        storeOrders.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openStoreOrdersView();
            }
        });
    }

    /**
     * Method to open the pizza view
     */
    public void openPizzaView() {
        Intent intent = new Intent(this, OrderPizzaActivity.class);
        startActivity(intent);
    }

    /**
     * Method to open the cart view
     */
    public void openCartView() {
        Intent intent = new Intent(this, ShoppingCartActivity.class);
        startActivity(intent);
    }

    /**
     * Method to open the Store orders View
     */
    public void openStoreOrdersView() {
//        Intent intent = new Intent(this, StoreOrdersActivity.class);
//        startActivity(intent);
    }

    /**
     * Method to get all Store orders
     * @return all store orders
     */
    public StoreOrder getAllOrdersFromStore() {
        return allOrdersFromStore;
    }
}

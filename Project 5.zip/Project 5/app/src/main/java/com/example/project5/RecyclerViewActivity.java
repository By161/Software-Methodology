package com.example.project5;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * The RecyclerViewActivity class that manages the pizza flavor view for the application
 * @author Brandon Yuen, Anna Kryzanekas
 */
public class RecyclerViewActivity extends AppCompatActivity implements RecyclerViewInterface {

    List<Item> pizzas = new ArrayList<Item>();

    /**
     * The onCreate method instantiates the recycler view
     * @param savedInstanceState the saved instance state
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.choose_flavor_main);

        RecyclerView recyclerView = findViewById(R.id.recyclerview);

        pizzas.add (new Item("Chicago Deluxe", R.drawable.deluxechicagopizza));
        pizzas.add (new Item("Chicago BBQ Chicken", R.drawable.chicagobbqchickenpizza));
        pizzas.add (new Item("Chicago Meatzza", R.drawable.chicagomeatzza));
        pizzas.add (new Item("Chicago Build Your Own", R.drawable.chicagomakeyourown));
        pizzas.add (new Item("NY Deluxe", R.drawable.nydeluxepizza));
        pizzas.add (new Item("NY BBQ Chicken", R.drawable.nybbqchicken));
        pizzas.add (new Item("NY Meatzza", R.drawable.meatzza));
        pizzas.add (new Item("NY Build Your Own", R.drawable.buildyourown));
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(new recyclerViewAdapter(getApplicationContext(), pizzas, this));
    }

    /**
     * method that determines what happens when an item is clicked within the recycler view
     * @param position index of the item that was clicked
     */
    @Override
    public void onItemClick(int position) {
        RecyclerView recyclerView = findViewById(R.id.recyclerview);
        Intent intent = new Intent(RecyclerViewActivity.this, editPizzaActivity.class);
        TextView textFlavor = recyclerView.
                findViewHolderForAdapterPosition(position).itemView.findViewById(R.id.name);
        String flavor = textFlavor.getText().toString();
        switch (flavor){
            case "Chicago Deluxe" : intent.putExtra("Flavor", "Chicago Deluxe");
                startActivity(intent);
                break;
            case "Chicago BBQ Chicken" : intent.putExtra("Flavor", "Chicago BBQ Chicken");
                startActivity(intent);
                break;
            case "Chicago Meatzza" : intent.putExtra("Flavor", "Chicago Meatzza");
                startActivity(intent);
                break;
            case "Chicago Build Your Own" : intent.putExtra("Flavor", "Chicago Build Your Own");
                startActivity(intent);
                break;
            case "NY Deluxe" : intent.putExtra("Flavor", "NY Deluxe");
                startActivity(intent);
                break;
            case "NY BBQ Chicken" : intent.putExtra("Flavor", "NY BBQ Chicken");
                startActivity(intent);
                break;
            case "NY Meatzza" : intent.putExtra("Flavor", "NY Meatzza");
                startActivity(intent);
                break;
            default:
                intent.putExtra("Flavor", "NY Build Your Own");
                startActivity(intent);
        }
    }
}
package com.example.project5;

public interface RecyclerViewInterface {
    void onItemClick(int position);
}

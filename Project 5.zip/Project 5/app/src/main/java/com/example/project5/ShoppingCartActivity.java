package com.example.project5;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;

public class ShoppingCartActivity extends AppCompatActivity {
    public static int orderNumber = 1;
    public static int orderNumberForLabel = 1;
    private Button removeButton;
    private Button clearOrderButton;
    private Button placeOrderButton;
    private ListView displayPizzas;
    private TextView orderNumberLabel;
    private TextView costBeforeTaxLabel;
    private TextView taxAmountLabel;
    private TextView totalCostLabel;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.shopping_cart);
//        displayPizzas = findViewById(R.id.displayPizas);
        orderNumberLabel = findViewById(R.id.orderNumberLabel);
        costBeforeTaxLabel = findViewById(R.id.costBeforeTaxLabel);
        taxAmountLabel = findViewById(R.id.taxAmountLabel);
        totalCostLabel = findViewById(R.id.totalCostLabel);
        removeButton = findViewById(R.id.removeButton);
        clearOrderButton = findViewById(R.id.clearOrderButton);
        placeOrderButton = findViewById(R.id.placeOrderButton);
//        displayPizzas = setOnItemClickListener(this);
        updateView();
    }

//    @Override
//    public void onItemClick() {
//
//    }
//
//    public void removeOrder() {
//
//    }
//
//    public void clearOrder() {
//
//    }
//
//    public void placeOrder() {
//
//    }

    private void updateLabel() {
        String costBeforeTax = MainActivity.allOrdersFromStore.getCurrentOrder().getCostBeforeTax();
        String taxAmount = MainActivity.allOrdersFromStore.getCurrentOrder().getTax();
        String totalCost = MainActivity.allOrdersFromStore.getCurrentOrder().getTotalCost();
        costBeforeTaxLabel.setText(costBeforeTax);
        taxAmountLabel.setText(taxAmount);
        totalCostLabel.setText(totalCost);
    }

    private void updateView() {
        if (MainActivity.allOrdersFromStore.getCurrentOrder().getNumPizzas() == 0) {
//            removeButton.setDisable(true);
//            placeOrderButton.setDisable(true);
//            clearOrderButton.setDisable(true);
        }
        ArrayList<String> orderedPizzas = new ArrayList<String>();
        for (int i = 0; i < MainActivity.allOrdersFromStore.getCurrentOrder().getNumPizzas(); i++) {
            if (MainActivity.allOrdersFromStore.getCurrentOrder().getPizza(i).contains("Brooklyn") ||
                    MainActivity.allOrdersFromStore.getCurrentOrder().getPizza(i).contains("Thin") ||
                    MainActivity.allOrdersFromStore.getCurrentOrder().getPizza(i).contains("Hand Tossed")){
                orderedPizzas.add("New York Style: " + MainActivity.allOrdersFromStore.getCurrentOrder().getPizza(i));
            }
            else{
                orderedPizzas.add("Chicago Style: " + MainActivity.allOrdersFromStore.getCurrentOrder().getPizza(i));
            }
        }
        if (MainActivity.allOrdersFromStore.getCurrentOrder().getNumPizzas() == 0) {
            orderedPizzas.add("Your pizza cart is empty!");
        }

//        displayPizzas.setItems(orderedPizzas);
        updateLabel();
        orderNumberLabel.setText(String.valueOf(MainActivity.allOrdersFromStore.getCurrentOrder().getOrderNumberForLabel()));
    }
}
package com.example.project5;
/**
 * Required class for the topping object
 * @author Brandon Yuen, Anna Kryzanekas
 */
public class Topping {
    String topping;
    /**
     * Constructor for the topping object
     * @param topping the topping
     */
    public Topping(String topping){
        this.topping = topping;
    }
}

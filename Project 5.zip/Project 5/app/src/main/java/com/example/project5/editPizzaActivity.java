package com.example.project5;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Arrays;

/**
 * Activity for editting your pizza and adding it to your order
 * @author Brandon Yuen, Anna Kryzanekas
 */
public class editPizzaActivity extends AppCompatActivity implements AdapterView.OnItemSelectedListener{

    public static final int MAX_NUM_TOPPINGS = 7;

    public static String pizzaSize;

    private Spinner sizes;

    private CheckBox sausageCB;

    private CheckBox pepperoniCB;

    private CheckBox greenPepperCB;

    private CheckBox onionCB;

    private CheckBox mushroomCB;

    private CheckBox BBQChickenCB;

    private CheckBox provoloneCB;

    private CheckBox cheddarCB;

    private CheckBox beefCB;

    private CheckBox redpepperCB;

    private CheckBox jalapenoCB;

    private CheckBox olivesCB;

    private CheckBox hamCB;

    private TextView label;

    private Button submit;

    private Button clearButton;

    private TextView crust;

    private Button checkPrice;

    AlertDialog.Builder builder;

    PizzaFactory chicagoPizzaToAdd = new ChicagoPizza();

    PizzaFactory nyPizzaToAdd = new NYPizza();

    public static Pizza pizza;

    public static ArrayList<String> listToppingsBuildYourOwn = new ArrayList<>();

    /**
     * onCreate assigns all of the UI elements to local variables and creates event listeners
     * for the buttons on the menu
     * @param savedInstanceState the saved instance state
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.order_pizza);
        assignUIElements();
        setOnClickListeners();
        String flavor = getIntent().getStringExtra("Flavor");
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this, R.array.sizes,
                android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        sizes.setAdapter(adapter);
        sizes.setOnItemSelectedListener(this);
        pizzaSize = sizes.getSelectedItem().toString();
        switch (flavor){
            case "Chicago Deluxe" : pizza = chicagoPizzaToAdd.createDeluxe();
                sausageCB.setChecked(true);
                pepperoniCB.setChecked(true);
                greenPepperCB.setChecked(true);
                onionCB.setChecked(true);
                mushroomCB.setChecked(true);
                clearButton.setEnabled(false);
                for (CheckBox checkBox : Arrays.asList(sausageCB, pepperoniCB, greenPepperCB,
                        onionCB, mushroomCB, BBQChickenCB, provoloneCB, cheddarCB, beefCB,
                        redpepperCB, jalapenoCB, olivesCB, hamCB)) {
                    checkBox.setEnabled(false);
                }
                crust.setText(R.string.chicagoDeluxeCrust);
                updateLabel();
                break;
            case "Chicago BBQ Chicken" : pizza = chicagoPizzaToAdd.createBBQChicken();
                BBQChickenCB.setChecked(true);
                greenPepperCB.setChecked(true);
                provoloneCB.setChecked(true);
                cheddarCB.setChecked(true);
                clearButton.setEnabled(false);
                for (CheckBox checkBox : Arrays.asList(sausageCB, pepperoniCB, greenPepperCB,
                        onionCB, mushroomCB, BBQChickenCB, provoloneCB, cheddarCB, beefCB,
                        redpepperCB, jalapenoCB, olivesCB, hamCB)) {
                    checkBox.setEnabled(false);
                }
                crust.setText(R.string.chicagoBBQChickenCrust);
                updateLabel();
                break;
            case "Chicago Meatzza" : pizza = chicagoPizzaToAdd.createMeatzza();
                sausageCB.setChecked(true);
                pepperoniCB.setChecked(true);
                beefCB.setChecked(true);
                hamCB.setChecked(true);
                clearButton.setEnabled(false);
                for (CheckBox checkBox : Arrays.asList(sausageCB, pepperoniCB, greenPepperCB,
                        onionCB, mushroomCB, BBQChickenCB, provoloneCB, cheddarCB, beefCB,
                        redpepperCB, jalapenoCB, olivesCB, hamCB)) {
                    checkBox.setEnabled(false);
                }
                crust.setText(R.string.chicagoMeatzzaCrust);
                updateLabel();
                break;
            case "Chicago Build Your Own" : pizza = chicagoPizzaToAdd.createBuildYourOwn();
                pizza.setToppings(listToppingsBuildYourOwn);
                crust.setText(R.string.chicagoBYOCrust);
                break;
            case "NY Deluxe" : pizza = nyPizzaToAdd.createDeluxe();
                sausageCB.setChecked(true);
                pepperoniCB.setChecked(true);
                greenPepperCB.setChecked(true);
                onionCB.setChecked(true);
                mushroomCB.setChecked(true);
                clearButton.setEnabled(false);
                for (CheckBox checkBox : Arrays.asList(sausageCB, pepperoniCB, greenPepperCB,
                        onionCB, mushroomCB, BBQChickenCB, provoloneCB, cheddarCB, beefCB,
                        redpepperCB, jalapenoCB, olivesCB, hamCB)) {
                    checkBox.setEnabled(false);
                }
                crust.setText(R.string.NYDeluxeCrust);
                updateLabel();
                break;
            case "NY BBQ Chicken" : pizza = nyPizzaToAdd.createBBQChicken();
                BBQChickenCB.setChecked(true);
                greenPepperCB.setChecked(true);
                provoloneCB.setChecked(true);
                cheddarCB.setChecked(true);
                clearButton.setEnabled(false);
                for (CheckBox checkBox : Arrays.asList(sausageCB, pepperoniCB, greenPepperCB,
                        onionCB, mushroomCB, BBQChickenCB, provoloneCB, cheddarCB,
                        beefCB, redpepperCB, jalapenoCB, olivesCB, hamCB)) {
                    checkBox.setEnabled(false);
                }
                crust.setText(R.string.nyBBQChickenCrust);
                updateLabel();
                break;
            case "NY Meatzza" : pizza = nyPizzaToAdd.createMeatzza();
                sausageCB.setChecked(true);
                pepperoniCB.setChecked(true);
                beefCB.setChecked(true);
                hamCB.setChecked(true);
                clearButton.setEnabled(false);
                for (CheckBox checkBox : Arrays.asList(sausageCB, pepperoniCB, greenPepperCB,
                        onionCB, mushroomCB, BBQChickenCB, provoloneCB, cheddarCB,
                        beefCB, redpepperCB, jalapenoCB, olivesCB, hamCB)) {
                    checkBox.setEnabled(false);
                }
                crust.setText(R.string.NYMeatzzaCrust);
                updateLabel();
                break;
            default: pizza = nyPizzaToAdd.createBuildYourOwn();
                pizza.setToppings(listToppingsBuildYourOwn);
                crust.setText(R.string.NYBYOcrust);
        }
    }

    /**
     * assignUIElements assigns the UI elements to local variables
     */
    private void assignUIElements() {
        sizes = (Spinner) findViewById(R.id.spinnerSize);
        sausageCB = findViewById(R.id.sausageCB);
        pepperoniCB = findViewById(R.id.pepperoniCB);
        greenPepperCB = findViewById(R.id.greenPepperCB);
        onionCB = findViewById(R.id.onionCB);
        mushroomCB = findViewById(R.id.mushroomCB);
        BBQChickenCB = findViewById(R.id.BBQChickenCB);
        provoloneCB = findViewById(R.id.provoloneCB);
        cheddarCB = findViewById(R.id.cheddarCB);
        beefCB = findViewById(R.id.beefCB);
        redpepperCB = findViewById(R.id.redpepperCB);
        jalapenoCB = findViewById(R.id.jalapenoCB);
        olivesCB = findViewById(R.id.olivesCB);
        hamCB = findViewById(R.id.hamCB);
        submit = findViewById(R.id.Order);
        label = findViewById(R.id.Price);
        builder = new AlertDialog.Builder(this);
        clearButton = findViewById(R.id.clearButton);
        crust = findViewById(R.id.crust);
        checkPrice = findViewById(R.id.buttonCheckPrice);
    }

    /**
     * setOnClickListeners sets the onClick listeners for each interactive element on the UI
     */
    private void setOnClickListeners() {
        sausageCB.setOnClickListener(view -> {
            updateAddOn(sausageCB, "Sausage");
            checkToppings();
        });
        pepperoniCB.setOnClickListener(view -> {
            updateAddOn(pepperoniCB, "pepperoni");
            checkToppings();
        });
        greenPepperCB.setOnClickListener(view -> {
            updateAddOn(greenPepperCB, "green pepper");
            checkToppings();
        });
        onionCB.setOnClickListener(view -> {
            updateAddOn(onionCB, "onion");
            checkToppings();
        });
        mushroomCB.setOnClickListener(view -> {
            updateAddOn(mushroomCB, "mushroom");
            checkToppings();
        });
        BBQChickenCB.setOnClickListener(view -> {
            updateAddOn(BBQChickenCB, "BBQ Chicken");
            checkToppings();
        });
        provoloneCB.setOnClickListener(view -> {
            updateAddOn(provoloneCB, "provolone");
            checkToppings();
        });
        cheddarCB.setOnClickListener(view -> {
            updateAddOn(cheddarCB, "cheddar");
            checkToppings();
        });
        beefCB.setOnClickListener(view -> {
            updateAddOn(beefCB, "beef");
            checkToppings();
        });
        redpepperCB.setOnClickListener(view -> {
            updateAddOn(redpepperCB, "red pepper");
            checkToppings();
        });
        jalapenoCB.setOnClickListener(view -> {
            updateAddOn(jalapenoCB, "jalapeno");
            checkToppings();
        });
        olivesCB.setOnClickListener(view -> {
            updateAddOn(olivesCB, "olives");
            checkToppings();
        });
        hamCB.setOnClickListener(view -> {
            updateAddOn(hamCB, "ham");
            checkToppings();
        });
        checkPrice.setOnClickListener(view -> updateLabel());
        clearButton.setOnClickListener(view -> {
            for (CheckBox checkBox : Arrays.asList(sausageCB, pepperoniCB, greenPepperCB, onionCB,
                    mushroomCB, BBQChickenCB, provoloneCB, cheddarCB, beefCB, redpepperCB,
                    jalapenoCB, olivesCB, hamCB)) {
                checkBox.setChecked(false);
                checkBox.setEnabled(true);
                listToppingsBuildYourOwn.clear();
                updateLabel();
            }
        });

        sizes.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            /**
             * onClickListener for the sizes spinner
             * @param adapterView the adapter view of the spinner
             * @param view the view of the spinner
             * @param i position of the spinner item
             * @param l needed for @Override
             */
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                pizzaSize = sizes.getSelectedItem().toString();
                updateLabel();
                submit.setEnabled(false);
            }

            /**
             * Method for when nothing is selected in the spinner, unused method but is needed for
             * the abstract class
             * @param adapterView the adapter view of the spinner
             */
            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {
            }
        });

        submit.setOnClickListener(view -> {
//                allOrdersFromStore.getCurrentOrder.add(pizza);
            Toast.makeText(editPizzaActivity.this, "Pizza added \n" + pizza.price,
                    Toast.LENGTH_SHORT).show();
            listToppingsBuildYourOwn.clear();
            Intent intent = new Intent(editPizzaActivity.this, RecyclerViewActivity.class);
            startActivity(intent); //go back to main menu
            sizes.setSelection(0);
        });
    }

    /**
     * Helper method to add selected toppings
     * @param box inputted chosen check box
     * @param name the topping associated with the check box
     */
    private void updateAddOn(CheckBox box, String name) {
        if (box.isChecked()) {
            listToppingsBuildYourOwn.add(name);
        } else {
            int index = pizza.getToppings().indexOf(name);
            listToppingsBuildYourOwn.remove(index);
        }
        updateLabel();
    }

    /**
     * updateLabel updates the price on the TextView to reflect the current price of the coffee
     */
    private void updateLabel() {
        Double price = pizza.price();
        String formattedTotal =  new DecimalFormat("#.##").format(price);
        label.setText(formattedTotal);
    }

    /**
     * Concrete method for on click events
     * @param adapterView adapter view of the list/spinner
     * @param view view of the list/spinner
     * @param i position of the item in the list/spinner
     * @param l needed for @Override
     */
    @Override
    public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
        pizzaSize = adapterView.getItemAtPosition(i).toString();
    }

    /**
     * Method for when nothing is selected in the spinner, unused method but is needed for
     * the abstract class
     * @param adapterView the adapter view of the spinner
     */
    @Override
    public void onNothingSelected(AdapterView<?> adapterView) {

    }

    /**
     * Helper method to call an alert box when the max amount of toppings is selected
     */
    public void checkToppings(){
        if(listToppingsBuildYourOwn.size() >= MAX_NUM_TOPPINGS){
            for (CheckBox checkBox : Arrays.asList(sausageCB, pepperoniCB, greenPepperCB, onionCB,
                    mushroomCB, BBQChickenCB, provoloneCB, cheddarCB, beefCB, redpepperCB,
                    jalapenoCB, olivesCB, hamCB)) {
                checkBox.setEnabled(false);
            }
            builder.setMessage(R.string.toppings_dialog_body)
                    .setTitle(R.string.Warning)
                    .setCancelable(true);
            AlertDialog dialog = builder.create();
            dialog.show();
        }
    }



}

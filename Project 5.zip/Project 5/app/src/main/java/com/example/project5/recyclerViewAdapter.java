package com.example.project5;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

/**
 * Adapter class for the recycler view
 * @author Brandon Yuen, Anna Kryzanekas
 */
public class recyclerViewAdapter extends RecyclerView.Adapter<recyclerViewAdapter.MyViewHolder> {

    private final RecyclerViewInterface recyclerViewInterface;

    Context context;

    private List<Item> pizzas;

    /**
     * Constructor for the adapter
     * @param context Context of the adapter
     * @param pizzas list of pizzas
     * @param recyclerViewInterface the interface needed for the recycler view
     */
    public recyclerViewAdapter(Context context, List<Item> pizzas,
                               RecyclerViewInterface recyclerViewInterface){
        this.context = context;
        this.pizzas = pizzas;
        this.recyclerViewInterface = recyclerViewInterface;
    }

    /**
     * Required method for the adapter
     * @param parent parent of the view holder
     * @param viewType the type of the view
     * @return a holder for the adapter
     */
    @NonNull
    @Override
    public recyclerViewAdapter.MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent,
                                                               int viewType) {
        LayoutInflater inflater = LayoutInflater.from(context);
        View view = inflater.inflate(R.layout.item_view, parent, false);
        return new recyclerViewAdapter.MyViewHolder(view, recyclerViewInterface);
    }

    /**
     * Required method for the adapter
     * @param holder holder of the adapter
     * @param position of the item in the recycler view
     */
    @Override
    public void onBindViewHolder(@NonNull recyclerViewAdapter.MyViewHolder holder, int position) {
        holder.pizzaFlavor.setText(pizzas.get(position).getFlavor());
        holder.imageView.setImageResource(pizzas.get(position).getImage());
    }

    /**
     * Helper method to get the amount of items in the recycler view
     * @return amount of items in the recycler view
     */
    @Override
    public int getItemCount() {
        return pizzas.size();
    }

    /**
     * inner class to hold data
     */
    public static class MyViewHolder extends RecyclerView.ViewHolder{

        ImageView imageView;
        TextView pizzaFlavor;

        /**
         * Constructor for the inner class
         * @param itemView the view of the Recycler view
         * @param recyclerViewInterface the recycler view interface
         */
        public MyViewHolder(@NonNull View itemView, RecyclerViewInterface recyclerViewInterface) {
            super(itemView);

            imageView = itemView.findViewById(R.id.imageview);
            pizzaFlavor = itemView.findViewById(R.id.name);

            itemView.setOnClickListener(new View.OnClickListener() {
                /**
                 * onClick listener for the recycler view
                 * @param view the view of the recycler view
                 */
                @Override
                public void onClick(View view) {
                    if(recyclerViewInterface != null){
                        int position = getAdapterPosition();
                        if(position != RecyclerView.NO_POSITION){
                            recyclerViewInterface.onItemClick(position);
                        }
                    }
                }
            });
        }
    }
}
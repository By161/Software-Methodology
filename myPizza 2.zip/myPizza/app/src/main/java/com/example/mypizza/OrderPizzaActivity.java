package com.example.mypizza;

public class OrderPizzaActivity extends AppCompatActivity implements AdapterView.OnItemClickListener {
}

package com.example.mypizza;

public class Item {
    String flavor;
    int image;

    public Item(String flavor, int image) {
        this.flavor = flavor;
        this.image = image;
    }

    public String getFlavor() {
        return flavor;
    }

    public void setFlavor(String flavor) {
        this.flavor = flavor;
    }

    public int getImage() {
        return image;
    }

    public void setImage(int image) {
        this.image = image;
    }
}

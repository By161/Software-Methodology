package com.example.mypizza;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    private Button orderPizza;
    private Button currentOrderCart;
    private Button storeOrders;
    private TextView welcomeText;
    public static StoreOrder allOrdersFromStore = new StoreOrder();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        Order currentOrder = new Order();
        allOrdersFromStore.add(currentOrder);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        orderPizza = findViewById(R.id.orderPizzaButton);
        currentOrderCart = findViewById(R.id.currentOrderCartButton);
        storeOrders = findViewById(R.id.storeOrdersButton);
        welcomeText = findViewById(R.id.welcome);
        orderPizza.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openPizzaView();
            }
        });
        currentOrderCart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openCartView();
            }
        });
        storeOrders.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openStoreOrdersView();
            }
        });
    }

    public void openPizzaView() {
        Intent intent = new Intent(this, RecyclerViewActivity.class);
        startActivity(intent);
    }

    public void openCartView() {
        Intent intent = new Intent(this, ShoppingCartActivity.class);
        startActivity(intent);
    }

    public void openStoreOrdersView() {
        Intent intent = new Intent(this, StoreOrdersActivity.class);
        startActivity(intent);
    }

    public static StoreOrder getAllOrdersFromStore() {
        return allOrdersFromStore;
    }
}

package com.example.mypizza;

public interface RecyclerViewInterface {
    void onItemClick(int position);
}

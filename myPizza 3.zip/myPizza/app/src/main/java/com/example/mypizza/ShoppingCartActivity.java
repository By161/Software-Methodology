package com.example.mypizza;

import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;

public class ShoppingCartActivity extends AppCompatActivity implements
        AdapterView.OnItemClickListener {

    public static int orderNumber = 1;
    public static int orderNumberForLabel = 1;
    private Button removeButton;
    private Button clearOrderButton;
    private Button placeOrderButton;
    private ListView displayPizzas;
    private TextView orderNumberLabel;
    private TextView costBeforeTaxLabel;
    private TextView taxAmountLabel;
    private TextView totalCostLabel;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_shopping_cart);
        orderNumberLabel = findViewById(R.id.orderNumberLabel);
        costBeforeTaxLabel = findViewById(R.id.costBeforeTaxLabel);
        taxAmountLabel = findViewById(R.id.taxAmountLabel);
        totalCostLabel = findViewById(R.id.totalCostLabel);
        removeButton = findViewById(R.id.removeButton);
        clearOrderButton = findViewById(R.id.clearOrderButton);
        placeOrderButton = findViewById(R.id.placeOrderButton);
        displayPizzas = findViewById(R.id.displayPizzas);
        displayPizzas.setOnItemClickListener(this);
        updateView();
    }

    @Override
    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
        if (MainActivity.allOrdersFromStore.getCurrentOrder().getNumPizzas() != 0) {
            AlertDialog.Builder removeAlert = new AlertDialog.Builder(this);
            removeAlert.setMessage("Would you like to remove this pizza from your cart?");
            removeAlert.setNegativeButton("No", new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface text, int which) {

                }
            });
            removeAlert.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialogInterface, int i) {
                    MainActivity.allOrdersFromStore.getCurrentOrder().remove(position);
                    updateView();
                }
            });
        }
        else {
            Toast toast = Toast.makeText(getApplicationContext(), "Your cart is empty!",
                    Toast.LENGTH_SHORT);
            toast.setGravity(Gravity.CENTER|Gravity.CENTER, 0, 0);
            toast.show();
        }
    }

    public void clearOrder() {
        if (MainActivity.allOrdersFromStore.getCurrentOrder().getNumPizzas() > 0) {
            for (int i = 0; i < MainActivity.allOrdersFromStore.getCurrentOrder().getNumPizzas();
            i++) {
                MainActivity.allOrdersFromStore.getCurrentOrder().remove(i);
            }
        }
        updateView();
    }

    public void placeOrder() {
        if (MainActivity.allOrdersFromStore.getCurrentOrder().getNumPizzas() > 0) {
            MainActivity.allOrdersFromStore.getCurrentOrder().makeCompleted();
            MainActivity.allOrdersFromStore.updateCurrentOrder();
            AlertDialog.Builder orderPlacedAlert = new AlertDialog.Builder(this);
            orderPlacedAlert.setMessage("Order Submitted");
            AlertDialog text = orderPlacedAlert.create();
            text.show();
        }
        updateView();
    }

    private void updateLabel() {
        String costBeforeTax = MainActivity.allOrdersFromStore.getCurrentOrder().getCostBeforeTax();
        String taxAmount = MainActivity.allOrdersFromStore.getCurrentOrder().getTax();
        String totalCost = MainActivity.allOrdersFromStore.getCurrentOrder().getTotalCost();
        costBeforeTaxLabel.setText(costBeforeTax);
        taxAmountLabel.setText(taxAmount);
        totalCostLabel.setText(totalCost);
    }

    private void updateView() {
        if (MainActivity.allOrdersFromStore.getCurrentOrder().getNumPizzas() == 0) {
            placeOrderButton.setEnabled(false);
            clearOrderButton.setEnabled(false);
        }
        ArrayList<String> orderedPizzas = new ArrayList<>();
        for (int i = 0; i < MainActivity.allOrdersFromStore.getCurrentOrder().
                getNumPizzas(); i++) {
            if (MainActivity.allOrdersFromStore.getCurrentOrder().getPizza(i).
                    contains("Brooklyn") ||
                    MainActivity.allOrdersFromStore.getCurrentOrder().getPizza(i).
                            contains("Thin") ||
                    MainActivity.allOrdersFromStore.getCurrentOrder().getPizza(i).
                            contains("Hand Tossed")){
                orderedPizzas.add("New York Style: " + MainActivity.allOrdersFromStore.
                        getCurrentOrder().getPizza(i));
            }
            else{
                orderedPizzas.add("Chicago Style: " + MainActivity.allOrdersFromStore.
                        getCurrentOrder().getPizza(i));
            }
        }
        if (MainActivity.allOrdersFromStore.getCurrentOrder().getNumPizzas() == 0) {
            orderedPizzas.add("Your pizza cart is empty!");
        }

        ArrayAdapter<String> adapter = new ArrayAdapter<>(this,
                android.R.layout.simple_list_item_1, orderedPizzas);
        displayPizzas.setAdapter(adapter);
        updateLabel();
        orderNumberLabel.setText(String.valueOf(MainActivity.allOrdersFromStore.getCurrentOrder().
                getOrderNumberForLabel()));
    }
}
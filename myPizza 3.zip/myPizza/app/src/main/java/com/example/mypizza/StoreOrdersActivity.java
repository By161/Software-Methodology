package com.example.mypizza;

import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;

public class StoreOrdersActivity extends AppCompatActivity implements
        AdapterView.OnItemClickListener {

    private final int SIZE_TO_SUBTRACT = 1;
    private TextView numberOfOrders;
    private ListView displayAllPlacedOrders;
    private ListView displayCurrentOrder;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_store_orders);
        numberOfOrders = findViewById(R.id.numberOfOrdersLabel);
        displayAllPlacedOrders = findViewById(R.id.placedOrders);
        displayCurrentOrder = findViewById(R.id.currentOrder);
        displayAllPlacedOrders.setOnItemClickListener(this);
        displayCurrentOrder.setOnItemClickListener(this);
        updateView();
    }

    @Override
    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
        if (MainActivity.allOrdersFromStore.getCurrentOrder().getNumPizzas() != 0) {
            AlertDialog.Builder removeAlertCurr = new AlertDialog.Builder(this);
            removeAlertCurr.setMessage("Would you like to remove this pizza from a customer's " +
                    "cart?");
            removeAlertCurr.setNegativeButton("No", new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface text, int which) {

                }
            });
            removeAlertCurr.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialogInterface, int i) {
                    MainActivity.allOrdersFromStore.getCurrentOrder().remove(position);
                    updateView();
                }
            });
        }
        if (MainActivity.getAllOrdersFromStore().getNumOfOrders() != 0) {
            AlertDialog.Builder removeAlertStore = new AlertDialog.Builder(this);
            removeAlertStore.setMessage("Would you like to clear this order from the database?");
            removeAlertStore.setNegativeButton("No", new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface text, int which) {

                }
            });
            removeAlertStore.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialogInterface, int i) {
                    MainActivity.getAllOrdersFromStore().remove(position);
                    updateView();
                }
            });
        }
    }

    private void updateView() {
        ArrayList<String> orders = new ArrayList<>();
        StoreOrder storeOrders = MainActivity.getAllOrdersFromStore();
        if (!storeOrders.get(0).isCompleted()) {
            orders.add("No orders placed yet!");
        }
        for (int i = 0; i < MainActivity.getAllOrdersFromStore().getNumOfOrders(); i++) {
            if (storeOrders.get(i).isCompleted()) {
                orders.add(storeOrders.get(i).toStringWithOrderNumber());
            }
        }
        ArrayAdapter<String> placedAdapter = new ArrayAdapter<>(this,
                android.R.layout.simple_list_item_1, orders);
        displayAllPlacedOrders.setAdapter(placedAdapter);

        ArrayList<String> pizzasToOrder = new ArrayList<>();
        for (int i = 0; i < MainActivity.allOrdersFromStore.getCurrentOrder().getNumPizzas(); i++) {
            pizzasToOrder.add(MainActivity.allOrdersFromStore.getCurrentOrder().getPizza(i));
        }
        if (MainActivity.allOrdersFromStore.getCurrentOrder().getNumPizzas() == 0) {
            pizzasToOrder.add("No active orders right now!");
        }
        ArrayAdapter<String> currAdapter = new ArrayAdapter<>(this,
                android.R.layout.simple_list_item_1, pizzasToOrder);
        displayCurrentOrder.setAdapter(currAdapter);

        numberOfOrders.setText(String.valueOf(MainActivity.getAllOrdersFromStore().getNumOfOrders()
                - SIZE_TO_SUBTRACT));
    }
}
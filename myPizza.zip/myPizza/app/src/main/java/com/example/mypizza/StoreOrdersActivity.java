package com.example.mypizza;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;

public class StoreOrdersActivity extends AppCompatActivity {
    private final int SIZE_TO_SUBTRACT = 1;
    private final int INDEX_OUT_OF_BOUNDS = -1;
    private Button removeButtonFromPlaced;
    private Button removeButtonFromCurrent;
    private Button exportButton;
    private TextView numberOfOrders;
    private ListView displayAllPlacedOrders;
    private ListView displayCurrentOrder;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_store_orders);
        removeButtonFromCurrent = findViewById(R.id.removeButtonFromCurrent);
        removeButtonFromPlaced = findViewById(R.id.removeButtonFromPlaced);
        exportButton = findViewById(R.id.exportButton);
        numberOfOrders = findViewById(R.id.numberOfOrdersLabel);
        displayAllPlacedOrders = findViewById(R.id.placedOrders);
        displayCurrentOrder = findViewById(R.id.currentOrder);
    }


}